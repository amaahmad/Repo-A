package com.cg.java.tests;


import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.DAO.EmpDAOImpl;
import com.cg.java.DTO.Emp;
import com.cg.java.Exception.EmpException;
import com.cg.java.services.EmpServiceImpl;

public class MainTest 
{
	public static void main (String args[])
	{
	ApplicationContext ctx = new ClassPathXmlApplicationContext("springCore.xml");
	EmpServiceImpl serviceimpl = (EmpServiceImpl)ctx.getBean("empService");

	   try {
		ArrayList<Emp> emplist = (ArrayList<Emp>) serviceimpl.getEmpList();
		for(int i=0;i<emplist.size();i++)
		{
			System.out.println(emplist.get(i).getEmpNm() +" "+ emplist.get(i).getEmpNo()+" " + emplist.get(i).getEmpSal());
		}
	} catch (EmpException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}

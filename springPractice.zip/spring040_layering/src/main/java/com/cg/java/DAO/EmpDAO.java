package com.cg.java.DAO;

import java.util.List;

import com.cg.java.DTO.Emp;
import com.cg.java.Exception.EmpException;

public interface EmpDAO 
{
	 public List<Emp> getEmpList() throws EmpException;
}

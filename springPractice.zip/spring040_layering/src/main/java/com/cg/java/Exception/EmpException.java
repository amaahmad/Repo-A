package com.cg.java.Exception;

public class EmpException extends Exception 
{
  EmpException(String message)
  {
	  
  }
  EmpException(String message, Throwable a)
  {
	  
  }
}

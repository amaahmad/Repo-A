package com.cg.java.DAO;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.java.DTO.Emp;
import com.cg.java.Exception.EmpException;

@Repository("Service")
public class EmpDAOImpl implements EmpDAO 
{

	public List<Emp> getEmpList() throws EmpException
	{
		List<Emp> empList = new ArrayList<Emp>();
		 Emp employee1 = new Emp();
		 employee1.setEmpNm("Amaan");
		 employee1.setEmpNo(3);
		 employee1.setEmpSal(60000);
		 
		 Emp employee2 = new Emp();
		 employee2.setEmpNm("Ahmad");
		 employee2.setEmpNo(4);
		 employee2.setEmpSal(56006);
		 
	   empList.add(employee1);
	   empList.add(employee2);
	   return empList;
	}

}

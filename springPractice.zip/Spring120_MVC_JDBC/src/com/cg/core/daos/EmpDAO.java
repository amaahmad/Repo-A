package com.cg.core.daos;

import java.util.List;

import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;

public interface EmpDAO 
{
   public List<Emp> getEmpList() throws EmpException;
}

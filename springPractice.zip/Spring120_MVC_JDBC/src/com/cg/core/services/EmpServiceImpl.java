package com.cg.core.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.cg.core.daos.EmpDAO;
import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;

@Service
@Scope("singleton")
public class EmpServiceImpl implements EmpService 
{ 
	@Autowired
	public EmpDAO dao;
	@Override
	public String authenticate(String username, String password) {
		if(username.equals("admin") && password.equals("password"))
			return "Amaan Ahmad";
		else
		return null;
	}

	@Override
	public List<Emp> getEmpList() throws EmpException {
		
		return dao.getEmpList();
	}

}

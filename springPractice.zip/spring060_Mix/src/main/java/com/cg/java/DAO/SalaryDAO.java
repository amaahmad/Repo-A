package com.cg.java.DAO;

import java.util.List;

import com.cg.java.DTO.EmpSal;
import com.cg.java.Exception.EmpException;

public interface SalaryDAO 
{
 public List<EmpSal> getEmpSalList() throws EmpException;
 

}

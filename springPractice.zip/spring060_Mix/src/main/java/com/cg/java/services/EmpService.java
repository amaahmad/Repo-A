package com.cg.java.services;

import java.util.List;

import com.cg.java.DAO.EmpDAO;
import com.cg.java.DTO.Emp;
import com.cg.java.DTO.EmpSal;
import com.cg.java.Exception.EmpException;


public interface EmpService
{
  public List<Emp> getEmpList() throws EmpException;
  
   public void setDao(EmpDAO dao);
   public List<EmpSal> getEmpSalList() throws EmpException;
 
}

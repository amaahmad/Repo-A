package com.cg.java.tests;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.services.EmpServices;
import com.cg.java.services.SalaryServices;

/*
 * The bean declaration is done using @Componenet
 * The initial value can be hard-coded using @Value 
 * There are 3 types of injection
 * Field injection= @Autowired on field
 * Constructor injection
 * Setter injection  */
public class Test010_Context {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("springCore.xml");
         System.out.println("****************");
		EmpServices services1 =  (EmpServices)ctx.getBean("empService");
	//	EmpServices services2 =  (EmpServices)ctx.getBean("empService");
		System.out.println(services1.getMessage());
	//	System.out.println(services2.getMessage());
//         SalaryServices service = (SalaryServices)ctx.getBean("salService");
        System.out.println(services1.getServices().calcSalary());
         ConfigurableApplicationContext cctx = (ConfigurableApplicationContext)ctx;
         cctx.close();
	}

}

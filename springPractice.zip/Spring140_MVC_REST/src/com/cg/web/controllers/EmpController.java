package com.cg.web.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;
import com.cg.core.services.EmpService;

//url= > http://localhost:8090/Spring140_MVC_REST/rest/empService/empList
@RestController
@RequestMapping("/empService")  //Name to identify the application
public class EmpController 
{    
	@Autowired
	private EmpService empService;
	
	@GetMapping(value="/empList",produces ="application/json") //convert empList to json
      //getmapping = requestmapping + get method type.
	public List<Emp> getempList()
	{ 
		List<Emp> empList = null;
		try {
			empList = empService.getEmpList();
		} catch (EmpException e) {
			
			e.printStackTrace();
		}
		return empList;
	}
} 

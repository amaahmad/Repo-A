package com.cg.core.DAO;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;


@Repository("empDAO")
public class EmpDAOImpl implements EmpDAO 
{     
	@Value("10")
	private int value;
	
	@Autowired
	private SalaryDAO dao;
	
  public EmpDAOImpl()
  {
	  System.out.println("EmpBean Created");
  }
@Override
public String toString() {
	return "EmpDAOImpl [value=" + value + "]";
}
  
}

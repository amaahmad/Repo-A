package com.cg.core.config;

import java.beans.PropertyDescriptor;

import org.springframework.beans.BeansException;
import org.springframework.beans.PropertyValues;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
import org.springframework.stereotype.Component;

import com.cg.core.DAO.EmpDAO;
import com.cg.core.DAO.EmpDAOImpl;
/* BeanProcessors are created before any other beans 
 * The postProcessBeforeInstantiation() is called for creating EmpDao
 * If this method returns instance of EmpDaoImpl, bean is created.
 * else spring creates the bean itself.
 * InstantiationAwareBeanPostProcessor is extended from BeanPostProcessor (not to be covered)
 * it contains 4 methods:
 *  postProcessBeforeInstantiation()
 *   postProcessAfterInstantiation()
 *   return 'true' : does data injection;
 *   return 'false' : bypasses data injection. this is called shortcircuiting.
 *   postProcessPropertyValues()
 *   postProcessProperties()
 *     postProcessBeforeInitialization() = Executed before calling the PostConstruct.
 *     postProcessBeforeInitialization() =  Executed after calling the PostConstruct.
 *     Before methods are called callback hooks.
 * */
@Component
public class BeanProcessorsImpl implements BeanPostProcessor// InstantiationAwareBeanPostProcessor
{    //1.
//	public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName) throws BeansException {
//	// Logic to programmatically create a bean goes here.(like in factory method).
//  	System.out.println(beanClass+" "+ beanName);
//  	System.out.println("PostProcessBeforeInstatiation");
////  	if(beanName.equals("empDAO"))
////  	{
////		EmpDAO dao = new EmpDAOImpl();
////		return dao;
////  	}
//		 //if we return null, spring applies it's object creation mechanism by itself. 
//	 	return null;
//	}
//	//2.
//	public boolean postProcessAfterInstantiation(Object bean, String beanName) throws BeansException {
//		 //if we return false, spring will do it's own initialization.
//		System.out.println("After instantiation");
//		return true;
//	}
//	//3.
//	public PropertyValues postProcessPropertyValues(PropertyValues pvs, PropertyDescriptor[] pds, Object bean,
//			String beanName) throws BeansException {
//		   System.out.println("postProcessPropertyValues");
//		return pvs;
//	}
//    //4.
//	public PropertyValues postProcessProperties(PropertyValues pvs, Object bean, String beanName)
//			throws BeansException {
//		  System.out.println("PostprocessProperties");
//		return pvs;
//	}
	/* Below two methods come from BeanPostProcessor 
	 * postProcessBeforeInitialization()
	 * postProcessAfterInitialization()*/
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		// TODO Auto-generated method stub
		//can be a place to validate the injections for a bean.
		System.out.println("Before Initialization");
		return bean;
	}
	
	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("After Initialization");
		return bean;
	}
	
}

package com.cg.core.DAO;

import java.util.List;

public interface SalaryDAO 
{
 

}

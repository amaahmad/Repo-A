package com.cg.java.tests;


import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.core.DAO.EmpDAO;


public class MainTest 
{
	public static void main (String args[])
	{
	ApplicationContext ctx = new ClassPathXmlApplicationContext("springCore.xml");
	System.out.println("******************");
     EmpDAO dao = (EmpDAO)ctx.getBean(EmpDAO.class);
     System.out.println(dao);
	}
}

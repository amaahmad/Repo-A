package com.cg.java.services;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/*
 * The interface initializingBean contains method afterPropertiesSet. 
 * the methods gets called automatically after setting all properties  */

/*  The interface DisposableBean contains method destroy 
 * the methods gets called automatically while bean is removed from spring context 
 * @Scope: To declare 'singleton' or 'prototype' for a bean.
 * @Scope("singleton") or @Scope("prototype")
 * */

/* Each bean by default is created eagerly i.e at the time of creation of spring context 
 * @Lazy(false): set by default
 * To create lazily => @Lazy(true)*/

/*@Component: to declare a bean 
 * Sub annotations of component ( for documentation purposes) 
 *  @Repository : to declare DAO classes as bean
 *  @Service : To declare business logic/service beans
 *  @Controller : Annotation to declare controlling classes in Spring MVC 
 *  @RestController: To declare REST services from a class in  spring REST. 
 *   */
@Service("empService")
@Scope("singleton")
@Lazy(true)
public class EmpServices //implements InitializingBean, DisposableBean <= Life cycle interfaces
{    
	@Value("Capgemini Pune")
	private String companyName;
	
	private String address;
	@Value("567688")
	private float yearlypackage;
	//@Autowired //field injection
	private SalaryServices services;
	
	public EmpServices(String companyName, String address) {
		super();
		System.out.println("In two para constructor");
		this.companyName = companyName;
		this.address = address;
	}
	
  public EmpServices(String companyName, String address, float yearlypackage) {
		super();
		System.out.println("in three para constructor");
		this.companyName = companyName;
		this.address = address;
		this.yearlypackage = yearlypackage;
	}
  

public String getMessage()
  {      
	  System.out.println(services.calcSalary());
	  return "Welcome to Spring training!"+" "+companyName +" "+address;
	 
  }
  public EmpServices()
  {
	  System.out.println("EmpService Object Created");
  }
  public String getCompanyName() { //companyName = property name
	return companyName;
  }
  
public void setCompanyName(String companyName) {
	this.companyName = companyName;
  }
public String getAddress() {  //address
	return address;
}
@Value("Talwade")
public void setAddress(String address) {
	this.address = address;
}
public SalaryServices getServices() { //services
	return services;
}
  @Autowired //setter injection
//byType: find the bean as per the type and not on 'id'
@Qualifier("salService")
//byName: find the bean based on the id.
public void setServices(SalaryServices services) {
	this.services = services;
}

@PostConstruct  //<= Bean life cycle method
//An annotation given by java. It declares an init method for a bean. 
//After creating a bean, spring context calls this method automatically.
//this allows naming the method according to choice.
public void afterPropertiesSet() throws Exception {

	System.out.println("In afterPropertiesSet");
}

@PreDestroy  //<= Bean life cycle method
//Is declares a finalizing method for a bean
//when the bean is removed from the spring context, this method is automatically called.
//Used to clean the resources. 
//method name can be as per choice. 
//PostConstruct and PreDestroy should be preferred over bean life cycle interfaces.
public void destroy() throws Exception {

	System.out.println("In destroy");
}

}
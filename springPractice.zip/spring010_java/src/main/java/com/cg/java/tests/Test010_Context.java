package com.cg.java.tests;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.services.EmpServices;
import com.cg.java.services.SalaryServices;

/*The bean and beans tags come from spring-beans.xsd
The bean tag takes at least two attributes
The class attribute takes fully qualified name of the bean
The id attribute is to uniquely identify a bean */
/* The ClassPathXmlApplicationContext is a spring container implementing interface
 *  ApplicationContext
 *  On creation of classPathXmlApplicationContext - refers to the configuration file 
 *  and creates every bean declared there.
 *  Two types of beans= 
 *  Singleton: Object created only once. by default it is singleton
 *  Prototype: Object created as and when required.
 *  Eager bean: All bean created at the time of creation of spring context.
 *  lazy : beans are created on demand only (.getBean)
 *  Prototype bean are always created lazily.(object created every time when .getBean method called)
 *  Singleton: eagerly/ lazily
 */
public class Test010_Context {

	public static void main(String[] args) {
		//1. Create spring context, Spring Container
		// BeanFactory factory = new XmlBeanFactory();
		// The ApplicationContext interface is a modified version of BeanFactory.
		//From Spring 4.3 onwards, BeanFactory is deprecated.
		ApplicationContext ctx = new ClassPathXmlApplicationContext("springCore.xml");
         System.out.println("****************");
		EmpServices services1 =  (EmpServices)ctx.getBean("empService");
	//	EmpServices services2 =  (EmpServices)ctx.getBean("empService");
		System.out.println(services1.getMessage());
	//	System.out.println(services2.getMessage());
//         SalaryServices service = (SalaryServices)ctx.getBean("salService");
        System.out.println(services1.getServices().calcSalary());

	}

}

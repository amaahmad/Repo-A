package com.cg.core.services;

public interface EmpService 
{
    public String authenticate(String username, String password);
}

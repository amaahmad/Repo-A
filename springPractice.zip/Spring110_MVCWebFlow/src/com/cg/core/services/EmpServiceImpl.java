package com.cg.core.services;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service
@Scope("singleton")
public class EmpServiceImpl implements EmpService 
{

	@Override
	public String authenticate(String username, String password) {
		if(username.equals("admin") && password.equals("password"))
			return "Amaan Ahmad";
		else
		return null;
	}

}

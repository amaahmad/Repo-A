package com.cg.core.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employees")
public class Emp 
{
	@Id
	@Column(name="EMPID")
  private int empId;
	@Column(name="EMPNAME")
  private String empName;
	@Column(name="SALARY")
  private float salary;
  
public Emp(int empId, String empName, float salary) {
	super();
	this.empId = empId;
	this.empName = empName;
	this.salary = salary;
}

public Emp() {
	super();
}

public int getEmpId() {  //empId
	return empId;
}

public void setEmpId(int empId) {
	this.empId = empId;
}

public String getEmpName() {  //empName
	return empName;
}

public void setEmpName(String empName) {
	this.empName = empName;
}

public float getSalary() {   //salary
	return salary;
}

public void setSalary(float salary) {
	this.salary = salary;
}

@Override
public String toString() {
	return "Emp [empId=" + empId + ", empName=" + empName + ", salary=" + salary + "]";
}
  
}

package com.cg.web.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;

import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;
import com.cg.core.services.EmpService;

//url= > http://localhost:8090/Spring130_MVC_JPA/empService/home.do
@Controller
@RequestMapping("/empService")  //Name to identify the application
public class EmpController 
{    
	@Autowired
	private EmpService empService;
	@RequestMapping("/home.do")
  public String getHomePage()
  {
	  return "Home";
  }
	@RequestMapping("/login.do")
	  public String getLoginPage()
	  {
		  return "Login";
	  }
	@RequestMapping("/authenticate.do")
	  public ModelAndView authenticate(@RequestParam("userName") String username,
			                      @RequestParam("password") String password)
	  {   
		//String username = req.getParameter("userName");
		//String password = req.getParameter("password"); 
		 String fullName = empService.authenticate(username, password);
		//System.out.println("User Name:" + username + " " +"Password:" + password);
		 ModelAndView mAndV = null;
		 if(fullName!=null)
		 {
			 mAndV = new ModelAndView("MainMenu");
			 mAndV.addObject("fullName", fullName);
		 }
		 else
		 {
			 mAndV = new ModelAndView("Login");
			 mAndV.addObject("msg", "Authentication Failed!");
		 }
		 return mAndV;
	  }
	@RequestMapping("/empList.do")
	public ModelAndView getempList()
	{ 
		List<Emp> empList = null;
		try {
			empList = empService.getEmpList();
		} catch (EmpException e) {
			
			e.printStackTrace();
		}
		ModelAndView mAndV = new ModelAndView();
		mAndV.addObject("empList", empList);
	    mAndV.setViewName("EmpList");  //second method to give view apart from constructor
		return mAndV;
	}
} 

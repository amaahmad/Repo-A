package com.cg.boot.Spring220_MVCBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring220MvcBootApplicationTests {

	@Test
	void contextLoads() {
	}

}

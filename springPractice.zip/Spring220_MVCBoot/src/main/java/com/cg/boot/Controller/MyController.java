package com.cg.boot.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

//http://localhost:8082/home.do
@Controller
public class MyController 
{
	@RequestMapping(value="/home.do")
 public String getHomePage()
 {
	 return "Home";
 }
}

package com.cg.boot.Spring220_MVCBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring220MvcBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring220MvcBootApplication.class, args);
	}

}

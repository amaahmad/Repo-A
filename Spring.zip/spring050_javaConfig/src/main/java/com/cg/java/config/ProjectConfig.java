package com.cg.java.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import com.cg.java.DAO.EmpDAO;
import com.cg.java.DAO.EmpDAOImpl;
import com.cg.java.services.EmpService;
import com.cg.java.services.EmpServiceImpl;

/* 
 * @Configuration : Class Level. Declares a class as Configuration class
 * @Bean : Method Level. Declares a method as a factory method ( Method responsible for 
 * creating, initializing an object, is a factory method.  
 *  */
/* This file is alternative to springCore.xml configuration file */
/* By default bean is singleton*/
// Lazy() and Scope() are also allowed on factory methods in Configuration class.
@Configuration
public class ProjectConfig 
{      
	@Autowired
	ApplicationContext ctx;
	@Bean("empDAO")
      // @Lazy(true)
      // @Scope("prototype")

    public EmpDAO getEmpDao()
    {
	System.out.println("Bean created");
    	return new EmpDAOImpl();
    }
       @Bean("empService")
       public EmpService getEmpService()
       { 
    	   EmpDAO dao = (EmpDAO)ctx.getBean("empDAO");
    	   EmpService service = new EmpServiceImpl();
    	   return service;
       }
}

package com.cg.java.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.java.DAO.EmpDAO;
import com.cg.java.DAO.EmpDAOImpl;
import com.cg.java.DTO.Emp;
import com.cg.java.Exception.EmpException;


//@Service("empService")
public class EmpServiceImpl implements EmpService
{  @Autowired
   private EmpDAO dao;
   
	public EmpDAO getDao() {
	return dao;
}

public void setDao(EmpDAO dao) {
	this.dao = dao;
}

	public List<Emp> getEmpList() throws EmpException {
		return dao.getEmpList();
	}
 
}

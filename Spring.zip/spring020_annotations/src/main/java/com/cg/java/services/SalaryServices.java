package com.cg.java.services;

import org.springframework.stereotype.Component;

@Component("salService")
public class SalaryServices 
{
  public SalaryServices()
  {
	  System.out.println("Object of salary created");
  }
  public String calcSalary()
  {
	  return "Salary Calculated ";
  }
}

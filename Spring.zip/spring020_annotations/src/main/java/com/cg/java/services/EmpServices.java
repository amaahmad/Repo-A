package com.cg.java.services;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/*
 * The interface initializingBean contains method afterPropertiesSet. 
 * the methods gets called automatically after setting all properties  */

/*  The interface DisposableBean contains method destroy 
 * the methods gets called automatically while bean is removed from spring context */
@Component("empService")
public class EmpServices //implements InitializingBean, DisposableBean
{    
	@Value("Capgemini Pune")
	private String companyName;
	
	private String address;
	@Value("567688")
	private float yearlypackage;
	//@Autowired //field injection
	private SalaryServices services;
	
	public EmpServices(String companyName, String address) {
		super();
		System.out.println("In two para constructor");
		this.companyName = companyName;
		this.address = address;
	}
	
  public EmpServices(String companyName, String address, float yearlypackage) {
		super();
		System.out.println("in three para constructor");
		this.companyName = companyName;
		this.address = address;
		this.yearlypackage = yearlypackage;
	}
  

public String getMessage()
  {      
	  System.out.println(services.calcSalary());
	  return "Welcome to Spring training!"+" "+companyName +" "+address;
	 
  }
  public EmpServices()
  {
	  System.out.println("EmpService Object Created");
  }
  public String getCompanyName() { //companyName = property name
	return companyName;
  }
  
public void setCompanyName(String companyName) {
	this.companyName = companyName;
  }
public String getAddress() {  //address
	return address;
}
@Value("Talwade")
public void setAddress(String address) {
	this.address = address;
}
public SalaryServices getServices() { //services
	return services;
}
  @Autowired //setter injection
//byType: find the bean as per the type and not on 'id'
@Qualifier("salService")
//byName: find the bean based on the id.
public void setServices(SalaryServices services) {
	this.services = services;
}

@PostConstruct
public void afterPropertiesSet() throws Exception {
	// TODO Auto-generated method stub
	System.out.println("In afterPropertiesSet");
}

@PreDestroy
public void destroy() throws Exception {
	// TODO Auto-generated method stub
	System.out.println("In destroy");
}

}
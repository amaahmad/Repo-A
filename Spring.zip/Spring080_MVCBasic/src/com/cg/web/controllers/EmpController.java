package com.cg.web.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
// url= > http://localhost:8090/Spring080_MVCBasic/empService/home.do

@Controller
@RequestMapping("/empService")  //Name to identify the application
public class EmpController 
{  
	@RequestMapping("/home.do")
  public String getHomePage()
  {
	  return "/WEB-INF/jsps/Home.jsp";
  }
}

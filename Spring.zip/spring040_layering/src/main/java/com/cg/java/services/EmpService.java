package com.cg.java.services;

import java.util.List;

import com.cg.java.DTO.Emp;
import com.cg.java.Exception.EmpException;


public interface EmpService
{
  public List<Emp> getEmpList() throws EmpException;
 
}

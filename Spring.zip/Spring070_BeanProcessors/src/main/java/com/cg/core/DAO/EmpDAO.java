package com.cg.core.DAO;

public interface EmpDAO 
{
	
}

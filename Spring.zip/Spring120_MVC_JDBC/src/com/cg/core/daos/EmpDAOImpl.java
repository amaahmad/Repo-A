package com.cg.core.daos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;


/*
 * Using connection pool is always a best practice instead of managing the connections.
 * Spring supports javax.sql.DataSource which is manager for pool of connections.
 * A DataSourcemanager is spring gives ready connection pool and DataSource. */
public class EmpDAOImpl implements EmpDAO 
{   
	@Autowired
   private DataSource  dataSource;
	@Override
	public List<Emp> getEmpList() throws EmpException {
        Connection connect = null;
        Statement stmt = null;
        ResultSet rs = null;
        String query = "Select empid,empname,salary from employees";
        List<Emp> empList = new ArrayList<>();
        try {
			connect = dataSource.getConnection();
			stmt = connect.createStatement();
			rs = stmt.executeQuery(query);
			while(rs.next())
			{
				int empId = rs.getInt(1);
				String empName = rs.getString(2);
				float sal = rs.getInt(3);
				
				Emp emp = new Emp(empId, empName, sal);
				empList.add(emp);
			}	
		}
        catch (SQLException e) {
		   throw new EmpException("Error while procuring data", e); // Exception chaining
		}
        finally
        {
        	try {
				if(rs!=null)
				rs.close();
				
				if(stmt!=null)
				stmt.close();
				
				if(connect!=null)
				connect.close();  // it will return the connection back to pool.
			} catch (SQLException e) {
				
				throw new EmpException("Error while closing the connection");
			} 
        }
      return empList;  
	}

}

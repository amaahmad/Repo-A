package com.cg.java.services;

public class SalaryServices 
{
  public SalaryServices()
  {
	  System.out.println("Object of salary created");
  }
  public String calcSalary()
  {
	  return "Salary Calculated ";
  }
}

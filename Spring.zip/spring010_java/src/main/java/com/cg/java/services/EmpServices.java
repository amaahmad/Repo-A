package com.cg.java.services;

public class EmpServices 
{
	private String companyName;
	private String address;
	private float yearlypackage;
	private SalaryServices services;
	
	public EmpServices(String companyName, String address) {
		super();
		System.out.println("In two para constructor");
		this.companyName = companyName;
		this.address = address;
	}
	
  public EmpServices(String companyName, String address, float yearlypackage) {
		super();
		System.out.println("in three para constructor");
		this.companyName = companyName;
		this.address = address;
		this.yearlypackage = yearlypackage;
	}

public String getMessage()
  {      
	  System.out.println(services.calcSalary());
	  return "Welcome to Spring training!"+" "+companyName +" "+address;
	 
  }
  public EmpServices()
  {
	  System.out.println("EmpService Object Created");
  }
  public String getCompanyName() { //companyName = property name
	return companyName;
  }
  
public void setCompanyName(String companyName) {
	this.companyName = companyName;
  }
public String getAddress() {  //address
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public SalaryServices getServices() { //services
	return services;
}
public void setServices(SalaryServices services) {
	this.services = services;
}
}
package com.cg.java.DAO;

import java.util.ArrayList;
import java.util.List;

import com.cg.java.DTO.EmpSal;
import com.cg.java.Exception.EmpException;

public class SalaryDAOImpl implements SalaryDAO 
{

	@Override
	public List<EmpSal> getEmpSalList() throws EmpException {
		List<EmpSal> empSalList = new ArrayList<>();
		empSalList.add(new EmpSal(3, 5500f, 500f));
		empSalList.add(new EmpSal(4, 5400f, 600f));
		
		return empSalList;
	}

}

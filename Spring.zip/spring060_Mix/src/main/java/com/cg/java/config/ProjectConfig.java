package com.cg.java.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import com.cg.java.DAO.EmpDAO;
import com.cg.java.DAO.EmpDAOImpl;
import com.cg.java.services.EmpService;
import com.cg.java.services.EmpServiceImpl;

/* 
 * @Configuration : Class Level. Declares a class as Configuration class
 * @Bean : Method Level. Declares a method as a factory method ( Method responsible for 
 * creating, initializing an object, is a factory method.  
 *  */
/* This file is alternative to springCore.xml configuration file */
/* By default bean is singleton*/
// Lazy() and Scope() are also allowed on factory methods in Configuration class.
//if the object creation is not straight forward use factory method, otherwise use ComponentScan

//3 approaches of bean configuration
//1.XML configuration - Bean is declared using <bean> in Spring XML configuration. Do not declare
//bean with componentscan, annotation and factory method.
//2.Annotation: (@Component, @Repository, @Service) - Mention componentscan in xml or 
//in JAVA config. Do not declare bean in factory method or xml.
//3. Factory method in Java config class. Do not annotate bean and no componentscan needed. 
 // Do not declare bean with <bean> in XML configuration.

//4. @ComponentScan: to mention packages to scan for annotated classes.
//5. @ImportResource: to import XML configuration.

@Configuration
@ImportResource("springCore.xml")
@ComponentScan("com.cg.java.services")
public class ProjectConfig 
{      
	@Autowired
	ApplicationContext ctx;
	
	@Bean("empDAO")
    public EmpDAO getEmpDao()
    {
	System.out.println("Bean created");
    	return new EmpDAOImpl();
    }
       
}

package com.cg.java.tests;


import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.DAO.EmpDAO;
import com.cg.java.DAO.EmpDAOImpl;
import com.cg.java.DTO.Emp;
import com.cg.java.Exception.EmpException;
import com.cg.java.config.ProjectConfig;
import com.cg.java.services.EmpService;
import com.cg.java.services.EmpServiceImpl;

public class MainTest 
{
	public static void main (String args[])
	{
	ApplicationContext ctx = new AnnotationConfigApplicationContext(ProjectConfig.class);
	System.out.println("******************");
     EmpService service1 = (EmpService) ctx.getBean("empService");
     EmpService service2 = (EmpService) ctx.getBean("empService");
    System.out.println(service1.hashCode() +" "+ service2.hashCode());
	   try {
		ArrayList<Emp> emplist = (ArrayList<Emp>)service1.getEmpList();
		for(int i=0;i<emplist.size();i++)
		{
			System.out.println(emplist.get(i).getEmpNm() +" "+ emplist.get(i).getEmpNo()+" " + emplist.get(i).getEmpSal());
		}
		System.out.println(service1.getEmpSalList());
	} catch (EmpException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
